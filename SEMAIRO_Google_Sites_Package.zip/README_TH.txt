ไฟล์สำหรับนำเกม SEMAIRO ไปใส่ใน Google Sites

1. อัปโหลดไฟล์ index.html ไปยัง GitHub repository ที่เปิดใช้ GitHub Pages
2. เปิด GitHub Pages เพื่อเผยแพร่เกมเป็นเว็บไซต์
3. คัดลอก URL เว็บไซต์ที่ GitHub Pages สร้างให้
4. เปิดไฟล์ google-sites-embed-code.html แล้วแทนที่
   https://YOUR-USERNAME.github.io/semairo/
   ด้วย URL เกมจริงของคุณ
5. คัดลอกโค้ด iframe ทั้งหมด
6. ใน Google Sites เลือก แทรก > ฝัง > ฝังโค้ด แล้ววางโค้ด
7. ปรับความสูงของกรอบตามต้องการ แล้วกดเผยแพร่

หมายเหตุ:
Google Sites ต้องฝังเกมจาก URL ที่เผยแพร่บนเว็บแล้ว
การวางไฟล์ HTML ลงใน Google Sites โดยตรงไม่ทำให้เกมทำงาน
โค้ด iframe นี้เตรียมสิทธิ์ fullscreen และ pointer lock สำหรับเกม 3D
